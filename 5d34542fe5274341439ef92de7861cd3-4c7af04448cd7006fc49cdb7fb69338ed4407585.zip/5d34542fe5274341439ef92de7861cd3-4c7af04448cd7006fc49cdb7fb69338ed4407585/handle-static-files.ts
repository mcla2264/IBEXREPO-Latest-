private configureApp(): void {
   this.app.use(express.static(path.join(__dirname, "../public")));
 }
